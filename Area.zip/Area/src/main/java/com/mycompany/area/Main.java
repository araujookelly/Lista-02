package com.mycompany.area;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        
        Scanner ler = new Scanner (System.in);
        
        Circulo areaCirculo = new Circulo();
        System.out.println("Digite o valor de raio");
        areaCirculo.setRaio(ler.nextDouble());
        
        Triangulo areaTriangulo = new Triangulo();
        System.out.println("Digite o valor da base do triangulo");
        areaTriangulo.setBase(ler.nextDouble());
        System.out.println("Digite o valor da altura do triangulo");
        areaTriangulo.setAltura(ler.nextDouble());
    
        Trapezio areaTrapezio = new Trapezio();
        System.out.println("Digite o valor da base Maior do trapezio");
        areaTrapezio.setBaseMaior(ler.nextDouble());
        System.out.println("Digite o valor da base Menor do trapezio");
        areaTrapezio.setBaseMenor(ler.nextDouble());
        System.out.println("Digite o valor da altura do trapezio");
        areaTrapezio.setAltura(ler.nextDouble());
        
        Quadrado areaQuadrado = new Quadrado();
        System.out.println("Digite o valor da base do quadrado");
        areaQuadrado.setBase(ler.nextDouble());
        System.out.println("Digite o valor da altura do quadrado");
        areaQuadrado.setAltura(ler.nextDouble());
        
        Retangulo areaRetangulo = new Retangulo();
        System.out.println("Digite o valor da base do retangulo");
        areaRetangulo.setBase(ler.nextDouble());
        System.out.println("Digite o valor da altura do retangulo");
        areaRetangulo.setAltura(ler.nextDouble());
        
        
        System.out.println("Area do circulo: " +areaCirculo.AreaCir());
        System.out.println("Area do triangulo: " +areaTriangulo.AreaTri());
        System.out.println("Area do Trapezio: " +areaTrapezio.AreaTra());
        System.out.println("Area do Quadrado " +areaQuadrado.AreaQuad());
        System.out.println("Area do Retangulo" +areaRetangulo.AreaRet());
        
        
    }
    
}
