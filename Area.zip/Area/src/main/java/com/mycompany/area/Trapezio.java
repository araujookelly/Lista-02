
package com.mycompany.area;


public class Trapezio {
    private double baseMenor, baseMaior, altura;

    public double getBaseMenor() {
        return baseMenor;
    }

    public void setBaseMenor(double baseMenor) {
        this.baseMenor = baseMenor;
    }
   
    
    public double getBaseMaior() {
        return baseMaior;
    }

    public void setBaseMaior(double base) {
        this.baseMaior = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    public double AreaTra(){
        double area;
        area=(altura*(baseMaior*baseMenor))/2;
        return 0;
    }
}
