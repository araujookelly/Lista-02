
package com.mycompany.area;

public class Circulo {
    private double raio;
    
    public double getRaio() {
        return raio;
    }
    
    public void setRaio(double raio) {
        this.raio = raio;
    }
    
      public double AreaCir(){
        double area;
        area=Math.pow(raio,2)*3.14159;
        return area;
        
    }

    class setRaio {

        public setRaio() {
        }
    }
}
