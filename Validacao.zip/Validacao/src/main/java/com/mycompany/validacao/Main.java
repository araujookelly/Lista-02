
package com.mycompany.validacao;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        
        Scanner ler = new Scanner (System.in);
        
        
        Media cMedia = new Media();
        do{
        System.out.println("Digite sua primeira nota");
        cMedia.setN1(ler.nextDouble());
        }while(cMedia.getN1()<1 && cMedia.getN1()<10);
        do{
        System.out.println("Digite sua segunda nota");
        cMedia.setN2(ler.nextDouble());
        }while(cMedia.getN2()<1 && cMedia.getN2()<10);
        
        System.out.println("Media:" +cMedia.calculoM());
    }
        
    
}
