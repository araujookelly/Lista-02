package com.mycompany.imposto;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Scanner ler = new Scanner (System.in);
        
        calculoIm cImposto = new calculoIm();
        System.out.println("Digite seu salario para calculo dos impostos: ");
        cImposto.setSalario(ler.nextDouble());
        
      
        if(cImposto.getSalario()>4500){
            cImposto.imposto=1000*0.08+1500*0.18;
            cImposto.diferenca=cImposto.salario-4500;
            cImposto.imposto+=cImposto.salario*0.28;
        }
        else
             if(cImposto.getSalario()>3000){
            cImposto.imposto=1000*0.08;
            cImposto.diferenca=cImposto.salario-3000;
            cImposto.imposto+=cImposto.salario*0.18;
        }
        else
         if(cImposto.getSalario()>2000){
            cImposto.diferenca=cImposto.salario-2000;
            cImposto.imposto+=cImposto.salario*0.08;
        }
        
        System.out.println("R$" +cImposto.imposto);
    }
    
}
