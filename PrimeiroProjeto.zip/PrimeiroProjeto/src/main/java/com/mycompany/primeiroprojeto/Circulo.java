
package com.mycompany.primeiroprojeto;


public class Circulo {
    private double raio;
    
    public double calcularAreaCirculo(){
        double area;
          area=Math.pow(raio,2)*3.14159;
          return area;
    }
    public void setRaio(double raio){
        this.raio=raio;
    }
    public double getRaio(){
        return this.raio;
    }
}
