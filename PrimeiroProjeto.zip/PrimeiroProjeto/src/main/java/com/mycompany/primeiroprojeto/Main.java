
package com.mycompany.primeiroprojeto;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
       Scanner ler = new Scanner (System.in);
       
       Circulo circulo1 = new Circulo();
        System.out.println("Digite o raio");
         circulo1.setRaio(ler.nextDouble());
        
        System.out.println("Area: " +circulo1.calcularAreaCirculo());
    }
    
}
