
import java.util.Scanner;
public class Main {

    
    public static void main(String[] args) {

        Scanner ler = new Scanner (System.in);
        
        notas mediaAluno = new notas();
        System.out.println("Digite a primeira nota: ");
        mediaAluno.setN1(ler.nextDouble());
        System.out.println("Digite a segunda nota: ");
        mediaAluno.setN2(ler.nextDouble());
        System.out.println("Digite a terceira nota: ");
        mediaAluno.setN3(ler.nextDouble());
        System.out.println("Digite a quarta nota: ");
        mediaAluno.setN4(ler.nextDouble());
        
        if(mediaAluno.mAluno()>=7){
            System.out.println("Aluno aprovado com media: " +mediaAluno.mAluno());
        }
        else
        if(mediaAluno.mAluno()<5){
            System.out.println("Aluno reprovado com media: " +mediaAluno.mAluno());
        }
        else
        if(mediaAluno.mAluno()>5 || mediaAluno.mAluno()<6.9){
            System.out.println("Aluno em exame com media: " +mediaAluno.mAluno());
        }
    }
    
    
    
}
